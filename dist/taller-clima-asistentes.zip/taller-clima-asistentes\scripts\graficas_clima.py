from pathlib import Path
import pandas as pd
import plotly.express as px

ROOT = Path.cwd()
EMA_CSV = ROOT / "data" / "emas" / "INSTITUTO_MEXICANO_DE_TECNOLOG__A_DEL_AGUA_90_dias.csv"
EPW = ROOT / "data" / "epw" / "MEX_MOR_Cuernavaca-Matamoros.Intl.AP.767260_TMYx.epw"
OUT = ROOT / "img" / "graficas-python"
OUT.mkdir(parents=True, exist_ok=True)

with EMA_CSV.open(encoding="utf-8-sig") as f:
    lines = f.readlines()
header_row = next(i for i, line in enumerate(lines) if line.startswith('"Fecha Local"'))
ema = pd.read_csv(EMA_CSV, skiprows=header_row)
ema["Fecha Local"] = pd.to_datetime(ema["Fecha Local"])
ema = ema.sort_values("Fecha Local").set_index("Fecha Local")

daily = ema.resample("D").agg({
    "Temperatura del Aire (°C)": "mean",
    "Humedad relativa (%)": "mean",
    "Radiación Solar (W/m²)": lambda x: x.sum() / 6 / 1000,
})
daily = daily.rename(columns={
    "Radiación Solar (W/m²)": "Energía solar estimada (kWh/m² día)"
})

fig = px.line(
    daily.reset_index(),
    x="Fecha Local",
    y=["Temperatura del Aire (°C)", "Humedad relativa (%)"],
    title="EMA IMTA: temperatura y humedad media diaria",
    labels={"value": "°C / %", "Fecha Local": "Fecha", "variable": "Variable"},
)
fig.write_html(OUT / "ema_temperatura_humedad.html")

fig = px.bar(
    daily.reset_index(),
    x="Fecha Local",
    y="Energía solar estimada (kWh/m² día)",
    title="EMA IMTA: energía solar diaria estimada",
    labels={"Fecha Local": "Fecha", "Energía solar estimada (kWh/m² día)": "kWh/m² día"},
    color_discrete_sequence=["#f59f00"],
)
fig.write_html(OUT / "ema_radiacion_diaria.html")

epw_cols = [
    "year","month","day","hour","minute","datasource","dry_bulb","dew_point","rh","pressure",
    "extr_horiz_rad","extr_direct_norm_rad","horiz_ir","ghi","dni","dhi",
    "global_horiz_illum","direct_norm_illum","diffuse_horiz_illum","zenith_lum",
    "wind_dir","wind_speed","total_sky_cover","opaque_sky_cover","visibility","ceiling_height",
    "present_weather_observation","present_weather_codes","precipitable_water","aerosol_optical_depth",
    "snow_depth","days_since_snow","albedo","liquid_precip_depth","liquid_precip_quantity",
]
epw = pd.read_csv(EPW, skiprows=8, header=None, names=epw_cols)
monthly = epw.groupby("month").agg(
    temp_mean=("dry_bulb", "mean"),
    temp_min=("dry_bulb", "min"),
    temp_max=("dry_bulb", "max"),
    ghi_kwh=("ghi", lambda x: x.sum() / 1000),
)

fig = px.line(
    monthly.reset_index(),
    x="month",
    y=["temp_min", "temp_mean", "temp_max"],
    markers=True,
    title="EPW Cuernavaca: temperatura mensual",
    labels={"month": "Mes", "value": "°C", "variable": "Indicador"},
)
fig.write_html(OUT / "epw_temperatura_mensual.html")

fig = px.bar(
    monthly.reset_index(),
    x="month",
    y="ghi_kwh",
    title="EPW Cuernavaca: radiación global horizontal mensual",
    labels={"month": "Mes", "ghi_kwh": "kWh/m² mes"},
    color_discrete_sequence=["#f59f00"],
)
fig.write_html(OUT / "epw_radiacion_mensual.html")
