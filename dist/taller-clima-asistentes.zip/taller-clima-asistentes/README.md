# Material del taller

Ciencia de datos y metodología para análisis del clima

## Estructura

- `data/epw/`: archivo EPW de Cuernavaca-Matamoros Intl. AP.
- `data/emas/`: CSV de la EMA Instituto Mexicano de Tecnología del Agua.
- `notebooks/analisis_clima.ipynb`: libreta Jupyter casi resuelta, con gráficas e indicadores para responder la actividad guiada.
- `scripts/graficas_clima.py`: script de apoyo con las gráficas resueltas en Plotly.
- `scripts/enerhabitat_demo.py`: ejemplo final de EnerHabitat usando el EPW del taller.
- `materials.ini`: materiales mínimos para ejecutar el ejemplo de EnerHabitat.
- `img/enerhabitat/`: gráficas simples generadas con Matplotlib.
- `img/graficas-python/`: carpeta para guardar las gráficas que se programen en la libreta.

## Datos incluidos

- EMA: 12628 registros, de 2026-01-30 20:10:00 a 2026-04-30 18:30:00.
- EPW: 8760 registros horarios.

## Requisitos

```bash
pip install --upgrade "pandas>=2.3" "numpy>=1.26,<2" plotly matplotlib jupyter enerhabitat
```

Abrir Jupyter desde esta carpeta para que las rutas relativas funcionen correctamente.

## Ejemplo final con EnerHabitat

Referencia del paquete: <https://pypi.org/project/enerhabitat/>

Después de ejecutar la libreta, se puede correr:

```bash
python scripts/enerhabitat_demo.py
```

El script usa el EPW incluido y `materials.ini` para generar gráficas PNG sencillas en `img/enerhabitat/`.
