from pathlib import Path

import matplotlib.pyplot as plt
import pandas as pd

from enerhabitat import Location, System, config


ROOT = Path(__file__).resolve().parents[1]
EPW = ROOT / "data" / "epw" / "MEX_MOR_Cuernavaca-Matamoros.Intl.AP.767260_TMYx.epw"
MATERIALS = ROOT / "materials.ini"
OUT = ROOT / "img" / "enerhabitat"
OUT.mkdir(parents=True, exist_ok=True)

ORIENTATIONS = {
    "Norte": 0,
    "Este": 90,
    "Sur": 180,
    "Oeste": 270,
}


def wall_tsa(location: Location, month: int, azimuth: int) -> pd.DataFrame:
    location.meanDay(day=15, month=month, year=2026)
    wall = System(
        location=location,
        tilt=90,
        azimuth=azimuth,
        absortance=0.65,
        layers=[("Concreto", 0.12), ("Aislamiento", 0.05), ("Yeso", 0.015)],
    )
    return wall.Tsa()


def plot_daily_comparison(location: Location, month: int = 5) -> Path:
    fig, ax = plt.subplots(figsize=(9, 4.8))

    for label, azimuth in ORIENTATIONS.items():
        data = wall_tsa(location, month, azimuth)
        hourly = data["Tsa"].resample("1h").mean()
        ax.plot(hourly.index.hour, hourly.values, marker="o", linewidth=1.8, label=label)

    ax.set_title("EnerHabitat: temperatura sol-aire por orientación, día medio de mayo")
    ax.set_xlabel("Hora del día")
    ax.set_ylabel("Temperatura sol-aire media (°C)")
    ax.set_xticks(range(0, 24, 2))
    ax.grid(True, alpha=0.3)
    ax.legend(title="Muro")
    fig.tight_layout()

    path = OUT / "muros_dia_medio_mayo.png"
    fig.savefig(path, dpi=160)
    plt.close(fig)
    return path


def plot_annual_comparison(location: Location) -> Path:
    rows = []
    for month in range(1, 13):
        for label, azimuth in ORIENTATIONS.items():
            data = wall_tsa(location, month, azimuth)
            rows.append(
                {
                    "Mes": month,
                    "Muro": label,
                    "Temperatura sol-aire media (°C)": data["Tsa"].mean(),
                }
            )

    annual = pd.DataFrame(rows)
    fig, ax = plt.subplots(figsize=(9, 4.8))
    for label in ORIENTATIONS:
        group = annual[annual["Muro"] == label]
        ax.plot(
            group["Mes"],
            group["Temperatura sol-aire media (°C)"],
            marker="o",
            linewidth=1.8,
            label=label,
        )

    ax.set_title("EnerHabitat: temperatura sol-aire media mensual por orientación")
    ax.set_xlabel("Mes")
    ax.set_ylabel("Temperatura sol-aire media (°C)")
    ax.set_xticks(range(1, 13))
    ax.grid(True, alpha=0.3)
    ax.legend(title="Muro")
    fig.tight_layout()

    path = OUT / "muros_promedio_anual.png"
    fig.savefig(path, dpi=160)
    plt.close(fig)
    return path


def main() -> None:
    config.file = str(MATERIALS)
    config.Nx = 80
    config.dt = 600

    location = Location(str(EPW))
    outputs = [
        plot_daily_comparison(location),
        plot_annual_comparison(location),
    ]
    print(
        {
            "location": location.city,
            "materials": config.materials_list(),
            "outputs": [path.name for path in outputs],
        }
    )


if __name__ == "__main__":
    main()
