# Material de trabajo del taller

Este paquete acompaña el taller **Ciencia de datos y metodología para análisis del clima**. Contiene datos climáticos, una libreta Jupyter guiada y scripts de apoyo para reproducir las gráficas del taller.

## Contenido

- `data/epw/`: archivo EPW de Cuernavaca-Matamoros Intl. AP.
- `data/emas/`: CSV de la EMA Instituto Mexicano de Tecnología del Agua.
- `notebooks/analisis_clima.ipynb`: libreta Jupyter casi resuelta para el análisis guiado.
- `scripts/graficas_clima.py`: script de apoyo con gráficas en Plotly.
- `scripts/enerhabitat_demo.py`: ejemplo final con EnerHabitat y Matplotlib.
- `materials.ini`: materiales mínimos para el ejemplo de EnerHabitat.
- `img/enerhabitat/`: gráficas simples generadas con Matplotlib.
- `requirements.txt`: dependencias de Python.

## Datos incluidos

- EMA: 12628 registros, de 2026-01-30 20:10:00 a 2026-04-30 18:30:00.
- EPW: 8760 registros horarios.

## Instalación de dependencias

Desde esta carpeta:

```bash
pip install -r requirements.txt
```

También se puede instalar con:

```bash
pip install --upgrade "pandas>=2.3" "numpy>=1.26,<2" plotly matplotlib jupyter enerhabitat
```

## Uso de la libreta

Abrir Jupyter desde la carpeta raíz de este paquete para que las rutas relativas funcionen correctamente:

```bash
jupyter notebook
```

Luego abrir:

```text
notebooks/analisis_clima.ipynb
```

## Ejemplo final con EnerHabitat

Referencia del paquete: <https://pypi.org/project/enerhabitat/>

El ejemplo preparado compara cuatro muros verticales: norte, este, sur y oeste. Usa el EPW incluido y `materials.ini`.

```bash
python scripts/enerhabitat_demo.py
```

El script genera gráficas PNG sencillas en:

```text
img/enerhabitat/
```
