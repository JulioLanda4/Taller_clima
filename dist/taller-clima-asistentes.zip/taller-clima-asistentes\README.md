# Material de trabajo del taller

Este paquete acompa?a el taller **Ciencia de datos y metodolog?a para an?lisis del clima**. Contiene datos clim?ticos, una libreta Jupyter guiada y recursos para ejecutar las gr?ficas del taller en la libreta.

## Contenido

- `data/epw/`: archivo EPW de Cuernavaca-Matamoros Intl. AP.
- `data/emas/`: CSV de la EMA Instituto Mexicano de Tecnolog?a del Agua.
- `notebooks/analisis_clima.ipynb`: libreta Jupyter para el an?lisis guiado.
- `materials.ini`: materiales m?nimos para el ejemplo de EnerHabitat.
- `img/enerhabitat/`: carpeta donde se guardan las gr?ficas del ejemplo final.
- `requirements.txt`: dependencias de Python.

## Datos incluidos

- EMA: 12628 registros, de 2026-01-30 20:10:00 a 2026-04-30 18:30:00.
- EPW: 8760 registros horarios.

## Instalaci?n de dependencias

Desde esta carpeta:

```bash
pip install -r requirements.txt
```

Tambi?n se puede instalar con:

```bash
pip install --upgrade "pandas>=2.3" "numpy>=1.26,<2" matplotlib jupyter enerhabitat
```

## Uso de la libreta

Abrir Jupyter desde la carpeta ra?z de este paquete:

```bash
jupyter notebook
```

Luego abrir:

```text
notebooks/analisis_clima.ipynb
```

La libreta tambi?n detecta la carpeta ra?z si se abre desde `notebooks/`.

## Ejemplo final con EnerHabitat

Referencia del paquete: <https://pypi.org/project/enerhabitat/>

El ejemplo compara cuatro muros verticales: norte, este, sur y oeste. Usa el EPW incluido y `materials.ini`, y se ejecuta directamente al final de la libreta.
